Pearl Results Android — Read-only test build

313 bundled lots. Home and Search only. Local ID/password setup and Android biometric prompt. No Add or Reports.

Build: JDK 17, Android SDK 35, Gradle 8.10.2; run gradle assembleDebug. GitHub Actions workflow included.

Important: no cloud sync, remote login, or automatic updates. Local login is not server authorization. Do not treat the APK as securely protecting sensitive auction data; embedded data can be extracted.
